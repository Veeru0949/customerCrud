export interface Customer {
    id?: number;
    firstName: string;
    lastName: string;
    email: string;
    createdDateTime?: string;
    lastUpdatedDateTime?: string;
  }
  